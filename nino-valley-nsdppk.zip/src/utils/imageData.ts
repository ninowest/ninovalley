interface Image {
  id: string;
  src: string;
  alt: string;
  title: string;
  description: string;
  photographer?: string;
  location?: string;
  date?: string;
}

export async function getImages(): Promise<Image[]> {
  return [
    {
      id: "1",
      src: "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba",
      alt: "Scenic mountain landscape",
      title: "Mountain Vista",
      description: "A breathtaking view of snow-capped peaks at sunrise",
      photographer: "John Doe",
      location: "Swiss Alps",
      date: "2023-04-28"
    },
    {
      id: "2",
      src: "https://images.unsplash.com/photo-1682687221038-404670f8f0ab",
      alt: "Coastal sunset",
      title: "Ocean Sunset",
      description: "Golden hour at the beach with waves crashing on shore",
      photographer: "Jane Smith",
      location: "Pacific Coast",
      date: "2023-04-29"
    },
    {
      id: "3",
      src: "https://images.unsplash.com/photo-1682687220063-4742bd7fd538",
      alt: "Forest pathway",
      title: "Forest Journey",
      description: "A serene path through an ancient forest",
      photographer: "Mike Johnson",
      location: "Redwood National Park",
      date: "2023-04-30"
    }
  ];
}

export async function getImageById(id: string): Promise<Image | undefined> {
  const images = await getImages();
  return images.find(image => image.id === id);
}